package com.example.filmster

import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.filmster.adapters.MovieAdapter
import com.example.filmster.adapters.TvShowAdapter
import com.example.filmster.viewmodels.MainViewModel
import com.google.android.material.appbar.MaterialToolbar

class MainActivity : AppCompatActivity() {

    private val TAG = "MainActivity"

    private lateinit var movieRecyclerView: RecyclerView
    private lateinit var movieAdapter: MovieAdapter
    private lateinit var tvShowRecyclerView: RecyclerView
    private lateinit var tvShowAdapter: TvShowAdapter
    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        val toolbar: MaterialToolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, 0, systemBars.right, systemBars.bottom)
            insets
        }

        movieRecyclerView = findViewById(R.id.movie_recycler_view)
        movieAdapter = MovieAdapter(emptyList())
        // Set layout manager to horizontal
        movieRecyclerView.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        movieRecyclerView.adapter = movieAdapter

        tvShowRecyclerView = findViewById(R.id.tv_show_recycler_view)
        tvShowAdapter = TvShowAdapter(emptyList())
        // Set layout manager to horizontal
        tvShowRecyclerView.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        tvShowRecyclerView.adapter = tvShowAdapter

        viewModel.movies.observe(this, Observer { movies ->
            movies?.let {
                Log.d(TAG, "Movies LiveData updated: ${it.size} movies")
                movieAdapter.updateData(it)
            }
        })

        viewModel.tvShows.observe(this, Observer { tvShows ->
            tvShows?.let {
                Log.d(TAG, "TV Shows LiveData updated: ${it.size} shows")
                tvShowAdapter.updateData(it)
            }
        })

        viewModel.error.observe(this, Observer { errorMessage ->
            errorMessage?.let {
                Log.e(TAG, "Error LiveData updated: $it")
                Toast.makeText(this, it, Toast.LENGTH_LONG).show()
            }
        })
    }
}
