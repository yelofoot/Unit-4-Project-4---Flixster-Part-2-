package com.example.filmster.activities

import android.os.Build
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.RoundedCorners
import com.bumptech.glide.request.RequestOptions
import com.example.filmster.R
import com.example.filmster.models.Movie
import com.example.filmster.viewmodels.MovieDetailsViewModel

class MovieDetailsActivity : AppCompatActivity() {

    private val viewModel: MovieDetailsViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_movie_details)

        val moviePosterImageView: ImageView = findViewById(R.id.movie_poster_image_view)
        val movieTitleTextView: TextView = findViewById(R.id.movie_title_text_view)
        val movieOverviewTextView: TextView = findViewById(R.id.movie_overview_text_view)
        val movieReleaseDateTextView: TextView = findViewById(R.id.movie_release_date_text_view)
        val movieVoteAverageTextView: TextView = findViewById(R.id.movie_vote_average_text_view)
        val movieVoteCountTextView: TextView = findViewById(R.id.movie_vote_count_text_view)

        moviePosterImageView.transitionName = "poster"

        val movie = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra("movie", Movie::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra<Movie>("movie")
        }

        if (movie != null) {
            viewModel.fetchMovieDetails(movie.id)
        }

        viewModel.movie.observe(this, {
            it?.let {
                Glide.with(this)
                    .load("https://image.tmdb.org/t/p/w500" + it.poster_path)
                    .apply(RequestOptions.bitmapTransform(RoundedCorners(20)))
                    .into(moviePosterImageView)

                movieTitleTextView.text = it.title
                movieOverviewTextView.text = it.overview
                movieReleaseDateTextView.text = "Release Date: ${it.release_date}"
                movieVoteAverageTextView.text = "Rating: ${it.vote_average}"
                movieVoteCountTextView.text = "Vote Count: ${it.vote_count}"
            }
        })
    }
}