package com.example.filmster.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.RoundedCorners
import com.bumptech.glide.request.RequestOptions
import com.example.filmster.R
import com.example.filmster.models.TvShow

class TvShowAdapter(private var tvShows: List<TvShow>) : RecyclerView.Adapter<TvShowAdapter.TvShowViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TvShowViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_tv_show, parent, false)
        return TvShowViewHolder(view)
    }

    override fun onBindViewHolder(holder: TvShowViewHolder, position: Int) {
        val tvShow = tvShows[position]
        holder.bind(tvShow)
    }

    override fun getItemCount(): Int = tvShows.size

    fun updateData(newTvShows: List<TvShow>) {
        tvShows = newTvShows
        notifyDataSetChanged()
    }

    inner class TvShowViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val titleTextView: TextView = itemView.findViewById(R.id.tv_show_title)
        private val posterImageView: ImageView = itemView.findViewById(R.id.tv_show_poster)

        fun bind(tvShow: TvShow) {
            titleTextView.text = tvShow.name

            val posterBaseUrl = "https://image.tmdb.org/t/p/w500"
            Glide.with(itemView.context)
                .load(posterBaseUrl + tvShow.poster_path)
                .apply(RequestOptions.bitmapTransform(RoundedCorners(20)))
                .placeholder(R.mipmap.ic_launcher)
                .error(R.mipmap.ic_launcher)
                .into(posterImageView)
        }
    }
}
