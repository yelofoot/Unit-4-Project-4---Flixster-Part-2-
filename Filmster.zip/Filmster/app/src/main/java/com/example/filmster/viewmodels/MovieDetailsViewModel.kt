package com.example.filmster.viewmodels

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.filmster.models.Movie
import com.example.filmster.network.ApiClient
import kotlinx.coroutines.launch
import java.io.IOException

class MovieDetailsViewModel : ViewModel() {

    private val apiKey = "a07e22bc18f5cb106bfe4cc1f83ad8ed"

    private val _movie = MutableLiveData<Movie>()
    val movie: LiveData<Movie> = _movie

    fun fetchMovieDetails(movieId: Int) {
        viewModelScope.launch {
            try {
                val movieDetails = ApiClient.movieApiService.getMovieDetails(movieId, apiKey)
                _movie.postValue(movieDetails)
            } catch (e: IOException) {
                // Handle network error
            } catch (e: Exception) {
                // Handle other errors
            }
        }
    }
}
